#coding:utf8
import os,time,psutil,warnings#reload()之前必须要引入模块# 
from threading import Thread as Th
def trec(target=None,
         args: tuple = (),
         kwargs: dict = None,
         filename: str = None,
         PRINT: bool = True,
         text: str = None,
         onerror=None):
    try:
        if target is not None:
            if args is not None and kwargs is not None:
                bo = target(*args, **kwargs)
            elif args is not None:
                bo = target(*args)
            elif kwargs is not None:
                bo = target(**kwargs)
            return 'ok', bo
        else:
            raise ValueError('不允许调用None空对象.')
    except Exception as e:
        nos = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime(time.time()))
        if text is not None:
            e = str(nos) + '==>' + str(text) +  str(e)
        else:
            e = str(nos) + '==>' + str(e)

        if filename is not None:
            if os.path.isfile(filename):
                po = os.path.split(filename)[0]
                if not os.path.exists(po):
                    os.makedirs(po)
                with open(filename, mode='a') as bug:
                    bug.write('%s\n' % str(e))
            else:
                if not os.path.exists(filename):
                    po = os.path.split(filename)[0]
                    if not os.path.exists(po):
                        os.makedirs(po)
                    with open(filename, mode='a') as bug:
                        bug.write('%s\n' % str(e))
                else:
                    print('Error:filename is the path of a file.')
        if onerror is not None:
            onerror(str(e))
        else:
            if PRINT:
                print(e)
        return 'error', str(e)
def pidFunction(name='',pid=0,output=False):
    '''
     作用：根据进程名获取进程pid
    '''
    result={'name':[],'pid':[],'ststus':[],'started':[]}

    pids = psutil.process_iter()
    if name:
        if output:
            print("[" + name + "]'s pid is:")
    if pid:
        if output:
            print("[" ,pid, "]'s name is:")
    for pidd in pids:
        #print(pidd)
        # pidd.ststus:running or stopped
        # pidd.started: run time
        if name:
            if(pidd.name() == name):
                if output:
                    print(pidd.pid)
                result['pid'].append(pidd.pid)
                result['ststus'].append(pidd.status())
                result['started'].append(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(pidd.create_time())))
        if pid:
            if pidd.pid==pid:
                if output:
                    print(pidd.name())
                result['name'].append(pidd.name())
                result['ststus'].append(pidd.status())
                result['started'].append(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(pidd.create_time())))
    warnings.warn("\n*******please pay attenion on the started:the time cannot be a part of any path.*******", UserWarning)
    if result['name'] or result['pid']:
        return True,result
    else:
        return False,result
